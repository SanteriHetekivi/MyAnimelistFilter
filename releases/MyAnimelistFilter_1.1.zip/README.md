# MyAnimeList Filter

Filters manga that is already in your MyAnimeList manga list and status is not Plan to Read.

Just give MyAnimeList manga list XML file in options.

Extension will filter manga on icon press.
Or if site's url is given in options as auto filter site, then filtering happens automatically.

Supported sites:
 *  http://myanimelist.net
 *  http://www.mangareader.net
 *  http://www.mangahere.co
 *  http://kissmanga.com
 *  http://www.mangaeden.com
 *  http://bato.to
 *  http://mangapark.me
 *  http://mangafox.me

